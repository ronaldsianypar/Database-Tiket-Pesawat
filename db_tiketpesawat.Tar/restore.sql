--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_typetransportasi DROP CONSTRAINT tb_typetransportasi_pkey;
ALTER TABLE ONLY public.tb_transportasi DROP CONSTRAINT tb_transportasi_pkey;
ALTER TABLE ONLY public.tb_rute DROP CONSTRAINT tb_rute_pkey;
ALTER TABLE ONLY public.tb_penumpang DROP CONSTRAINT tb_penumpang_pkey;
ALTER TABLE ONLY public.tb_pemesanan DROP CONSTRAINT tb_pemesanan_pkey;
ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
DROP TABLE public.tb_typetransportasi;
DROP TABLE public.tb_transportasi;
DROP TABLE public.tb_rute;
DROP TABLE public.tb_petugas;
DROP TABLE public.tb_penumpang;
DROP TABLE public.tb_pemesanan;
DROP TABLE public.tb_level;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(4) NOT NULL,
    nama_level character varying(10)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_pemesanan (
    id_pemesanan character varying(4) NOT NULL,
    kode_pemesanan character varying(4),
    tanggal_pemesanan date,
    tempat_pemesanan character varying(25),
    id_pelanggan character varying(4),
    kode_kursi character varying(4),
    id_rute character varying(4),
    tujuan character varying(50),
    tanggal_berangkat date,
    jam_cekin time without time zone,
    jam_berangkat time without time zone,
    total_bayar integer,
    id_petugas character varying(4)
);


ALTER TABLE tb_pemesanan OWNER TO postgres;

--
-- Name: tb_penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_penumpang (
    id_penumpang character varying(4) NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_penumapang character varying(50),
    alamat_penumpan text,
    tanggal_lahir date,
    jenis_kelamin character varying(10),
    telepon character varying(13)
);


ALTER TABLE tb_penumpang OWNER TO postgres;

--
-- Name: tb_petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_petugas (
    id_petugas character varying(4),
    username character varying(50),
    password character varying(50),
    nama_petugas character varying(50),
    id_level character varying(4)
);


ALTER TABLE tb_petugas OWNER TO postgres;

--
-- Name: tb_rute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_rute (
    id_rute character varying(4) NOT NULL,
    tujuan character varying(100),
    rute_awal character varying(100),
    rute_akhir character varying(100),
    harga integer,
    id_transportasi character varying(4)
);


ALTER TABLE tb_rute OWNER TO postgres;

--
-- Name: tb_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_transportasi (
    id_transportasi character varying(4) NOT NULL,
    kode character varying(4),
    jumlah_kursi integer,
    keterangan character varying(20),
    id_type_transportasi character varying(4)
);


ALTER TABLE tb_transportasi OWNER TO postgres;

--
-- Name: tb_typetransportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_typetransportasi (
    id_transportasi character varying(4) NOT NULL,
    nama_type character varying(50),
    keterangan character varying(20)
);


ALTER TABLE tb_typetransportasi OWNER TO postgres;

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: tb_pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM stdin;
\.
COPY tb_pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM '$$PATH$$/2826.dat';

--
-- Data for Name: tb_penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_penumpang (id_penumpang, username, password, nama_penumapang, alamat_penumpan, tanggal_lahir, jenis_kelamin, telepon) FROM stdin;
\.
COPY tb_penumpang (id_penumpang, username, password, nama_penumapang, alamat_penumpan, tanggal_lahir, jenis_kelamin, telepon) FROM '$$PATH$$/2827.dat';

--
-- Data for Name: tb_petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY tb_petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: tb_rute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM stdin;
\.
COPY tb_rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: tb_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM stdin;
\.
COPY tb_transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: tb_typetransportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_typetransportasi (id_transportasi, nama_type, keterangan) FROM stdin;
\.
COPY tb_typetransportasi (id_transportasi, nama_type, keterangan) FROM '$$PATH$$/2832.dat';

--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- Name: tb_pemesanan tb_pemesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_pemesanan
    ADD CONSTRAINT tb_pemesanan_pkey PRIMARY KEY (id_pemesanan);


--
-- Name: tb_penumpang tb_penumpang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_penumpang
    ADD CONSTRAINT tb_penumpang_pkey PRIMARY KEY (id_penumpang);


--
-- Name: tb_rute tb_rute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_rute
    ADD CONSTRAINT tb_rute_pkey PRIMARY KEY (id_rute);


--
-- Name: tb_transportasi tb_transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_transportasi
    ADD CONSTRAINT tb_transportasi_pkey PRIMARY KEY (id_transportasi);


--
-- Name: tb_typetransportasi tb_typetransportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_typetransportasi
    ADD CONSTRAINT tb_typetransportasi_pkey PRIMARY KEY (id_transportasi);


--
-- PostgreSQL database dump complete
--

